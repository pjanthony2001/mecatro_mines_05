SparkFun Arduino Examples
==========================

Example Briefs
--------------

* AveragingReadBarOnly - This reads the bar at 40Hz and displays average at 115200 baud.
* MostBasicFollower - This causes a RedBot Shadow Chassis to follow a line.  Motor Polarity may be opposite for other bots.
* ReadBarOnly - This reads the bar every 2/3 second and displays to serial at 9600 baud.
